BOOMEdit Remake by silverweed
------------------------------------------------------

## How to use ##

### STEP 1: Get BOOM: Remake ###
In order to use this program you need to have *BOOM: Remake* somewhere on your PC.
If you don't, you can get it for free here:

		https://silverweed.github.io/boom

### STEP 2: Find the location of the levels file you wanna edit ###
The first time you start the level editor, a file dialog will appear asking for the location of a *BOOMEdit: Remake* levels file.
This is usually called `levels.json` and can be found inside your *BOOM: Remake* folder.

Once you select this file, the level editor will properly open and you'll be able to edit levels as you like.

### STEP 3: Saving the levels ###
When you're done editing the levels, save them by using 'Save As' or Ctrl+Shift+S.

!!! BE AWARE THAT IF YOU PRESS 'SAVE' OR DO CTRL+S YOU'LL OVERWRITE THE LATEST SAVED FILE !!!
!!! IF YOU DIDN'T USE 'SAVE AS' YET, THIS WILL BE YOUR ORIGINAL LEVELS !!!

If you accidentally overwrite the levels and still have the level editor open, don't panic. You can recover them easily by doing this:

1. Save your edited levels on another file ('Save As' or Ctrl+Shift+S)
2. Press 'Restore All'
3. Save the now-restored levels on the initial file you opened ('Save As' or Ctrl+Shift+S. Don't do just 'Save' or you'll overwrite the file you just saved your edited levels in).

If you *don't* have the level editor open, your original levels are gone. You can still recover the default levels by redownloading the game or by just downloading this file: https://codeberg.org/silverweed/lifish/raw/branch/boom/levels.json

### STEP 4: Using your new levels ###
By default, *BOOM: Remake* will try to use the `levels.json` file that's inside its folder. That said, there are 2 ways you can launch the game with your custom levels.

- Method 1: backup + overwrite:
	Every time you want to edit the levels, do the following steps:
		1. backup the current `levels.json` (e.g. to `levels.json.bak`, but you can call the file however you want)
		2. edit `levels.json` with the level editor
		3. when you're done editing, overwrite the file by just using 'Save' (or Ctrl+S).

	When you want to restore the levels, just replace `levels.json` with the backup you created earlier.

- Method 2: command line argument:
	If you launch *BOOM: Remake* from the terminal you can pass which level file it should use as an argument.
	For example, if you created a custom levels file called `my_levels.json`, you can launch the game like this:

		./lifish my_levels.json
	
	This way you don't need to backup anything.
