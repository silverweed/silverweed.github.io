------------------------------------
BOOM Remake by silverweed
v. 1.8.2
https://github.com/silverweed/lifish
------------------------------------

The game will only work on a 64bit Windows.

Read the latest patch notes at https://silverweed.github.io/boom/
